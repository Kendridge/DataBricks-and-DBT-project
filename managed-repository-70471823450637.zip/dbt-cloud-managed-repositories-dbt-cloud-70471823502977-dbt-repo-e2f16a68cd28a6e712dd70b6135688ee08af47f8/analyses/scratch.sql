SELECT *
FROM {{ source('source_bronze','trips')}}